local M = {}

function M.setup()
    require("mytheme.ui")
    require("mytheme.treesitter")
end

return M
