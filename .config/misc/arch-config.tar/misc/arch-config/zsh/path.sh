export PATH="$PATH:$HOME/bin"
